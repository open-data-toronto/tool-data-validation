BUSINESS_IMPROVEMENT_AREA_WGS84_readme
 

Column name  (Description)
======================================
GEO_ID = AREA_ID  (Unique number for geographic feature)
TYPE_DESC = AREA_TYPE
TYPE_CODE = AREA_CLASS
LCODE_NAME = AREA_LONG_CODE
NAME = AREA_NAME  (Name of the Business Improvement Areas (BIA))
OBJECTID = OBJECTID  (Unique system identifier)
